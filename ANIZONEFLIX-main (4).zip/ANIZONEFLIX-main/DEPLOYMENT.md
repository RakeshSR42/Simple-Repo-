# AniZoneFlix Production Deployment Guide

This guide provides instructions for deploying the AniZoneFlix executive suite to production environments.

## 1. Environment Variables

Ensure the following variables are set in your deployment environment:

| Variable | Description | Example |
| :--- | :--- | :--- |
| `API_ID` | Telegram API ID | `1234567` |
| `API_HASH` | Telegram API Hash | `abcdef123456...` |
| `BOT_TOKEN` | Telegram Bot Token | `1234:ABC-DEF...` |
| `MONGO_URI` | MongoDB Atlas Connection String | `mongodb+srv://...` |
| `ADMIN_IDS` | Comma-separated Admin Telegram IDs | `12345678,87654321` |
| `BASE_URL` | Your Production URL | `https://anizoneflix.onrender.com` |
| `LOGO_URL` | Website Logo URL | `https://.../logo.png` |

## 2. Render Deployment (Full Suite)

Render is recommended for hosting both the Web Server and the Telegram Bot in a single environment.

1. **New Web Service**: Connect your GitHub repository.
2. **Runtime**: `Python 3`
3. **Build Command**: `pip install -r requirements.txt`
4. **Start Command**: `python app.py`
5. **Environment**: Add all variables from Section 1.
6. **Health Check Path**: `/` (Render uses `HEAD` requests, which are supported).

## 3. Vercel Deployment (Frontend Only)

If you wish to host the frontend separately:

1. **Build Command**: None (Static files are served directly by the backend).
2. **Note**: Since this is a FastAPI application, Vercel requires a `vercel.json` configuration for Serverless Functions if you are not using the Render approach.

## 4. Manual / Docker Deployment

```bash
# Build
docker build -t anizoneflix .

# Run
docker run -p 10000:10000 --env-file .env anizoneflix
```

## 5. Post-Deployment Verification

1. Access `https://your-app.onrender.com/ping`.
2. Ensure `db` and `bot` status are both `true`.
3. Open your Telegram Bot and send `/start`.
4. Verify that `/search` returns results from the multi-API aggregator.


## Vercel website deployment (website only)

1. Import the repository into Vercel and keep the project root set to the repository root.
2. Add `WEB_ONLY=true`, `BASE_URL`, `DB_NAME`, `MONGO_URI`, and a strong random `SECRET_KEY` in Project Settings → Environment Variables.
3. Deploy. `vercel.json` routes requests through `deployment/api/index.py`; static assets, templates, and app code are loaded from the repository root.
4. Check `/ping`, `/`, and `/search` after deployment. MongoDB must be reachable for database content to appear.
5. Do not run the Telegram polling bot on Vercel. Deploy it separately to Render with `WEB_ONLY=false` and the bot credentials.

**Security:** never commit `.env` or real connection strings. Rotate any database password or secret that was previously committed. Configure a least-privilege MongoDB user and restrict database network access where your hosting setup permits it. Client-side anti-scraping scripts are not security boundaries; use server-side controls and an edge WAF/rate limiter.


## Separate Vercel directory

See [`vercel/DEPLOYMENT.md`](vercel/DEPLOYMENT.md) for Vercel-specific environment
variables, `vercel/config.py` fallback settings, and the website-only serverless
entry point. Vercel URL detection is automatic on Vercel. For the Render bot, set
`BASE_URL` to the stable Vercel production URL; Render cannot discover another
platform's URL merely because it uses the same repository.
