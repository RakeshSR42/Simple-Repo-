document.addEventListener('DOMContentLoaded', () => {
    console.log('ANIZONEFLIX Production Suite LIVE');

    // Security is enforced server-side; avoid blocking accessibility or browser tools.

    // --- Theme Toggle Logic ---
    const initThemeToggle = () => {
        const toggleBtn = document.getElementById('theme-toggle');
        if (!toggleBtn) return;

        const currentTheme = localStorage.getItem('theme') || 'dark';
        const icon = toggleBtn.querySelector('i');
        if (currentTheme === 'light') {
            document.documentElement.classList.add('light-theme');
            if (icon) {
                icon.className = 'fa-solid fa-sun text-[var(--accent)]';
            }
        } else {
            document.documentElement.classList.remove('light-theme');
            if (icon) {
                icon.className = 'fa-solid fa-moon text-[var(--accent)]';
            }
        }

        toggleBtn.addEventListener('click', () => {
            const isLight = document.documentElement.classList.contains('light-theme');
            const icon = toggleBtn.querySelector('i');
            if (isLight) {
                document.documentElement.classList.remove('light-theme');
                localStorage.setItem('theme', 'dark');
                if (icon) icon.className = 'fa-solid fa-moon text-[var(--accent)]';
            } else {
                document.documentElement.classList.add('light-theme');
                localStorage.setItem('theme', 'light');
                if (icon) icon.className = 'fa-solid fa-sun text-[var(--accent)]';
            }
        });
    };
    initThemeToggle();

    // --- Interactive Elements: Ripple Effect ---
    const createRipple = (event) => {
        const button = event.currentTarget;
        const circle = document.createElement('span');
        const diameter = Math.max(button.clientWidth, button.clientHeight);
        const radius = diameter / 2;
        const rect = button.getBoundingClientRect();

        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${event.clientX - rect.left - radius}px`;
        circle.style.top = `${event.clientY - rect.top - radius}px`;
        circle.classList.add('ripple');

        const ripple = button.getElementsByClassName('ripple')[0];
        if (ripple) { ripple.remove(); }
        button.appendChild(circle);

        setTimeout(() => circle.remove(), 600);
    };

    document.querySelectorAll('.btn-premium, button').forEach(btn => {
        btn.addEventListener('click', createRipple);
    });

    // --- Mobile Menu Toggle ---
    window.toggleMenu = (show) => {
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu) {
            if (show) {
                mobileMenu.classList.remove('hidden');
                mobileMenu.classList.add('animate-fade-in');
            } else {
                mobileMenu.classList.add('hidden');
            }
        }
    };

    // --- Lazy Loading Enhancement ---
    if ('IntersectionObserver' in window) {
        const imgObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    observer.unobserve(img);
                }
            });
        }, { rootMargin: '50px' });
        document.querySelectorAll('img[loading="lazy"]').forEach(img => imgObserver.observe(img));
    }

    // --- Auto-scroll Rows Pause/Resume ---
    document.querySelectorAll('.ott-row, .swiper').forEach(row => {
        row.addEventListener('mouseenter', () => {
            if (row.swiper && row.swiper.autoplay) row.swiper.autoplay.stop();
        });
        row.addEventListener('mouseleave', () => {
            if (row.swiper && row.swiper.autoplay) row.swiper.autoplay.start();
        });
    });

    // --- Floating Search Button ---
    const floatingSearch = document.querySelector('.search-btn-floating');
    if (floatingSearch) {
        floatingSearch.addEventListener('click', () => {
            window.location.href = '/search';
        });
    }
});
