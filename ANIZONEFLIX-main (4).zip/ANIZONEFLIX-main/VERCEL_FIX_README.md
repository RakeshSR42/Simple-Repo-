# ANIZONEFLIX Vercel deployment fix

## What was fixed
- `vercel.json` now builds the real root `api/index.py` entry point (the previous configuration pointed at `vercel/api/index.py`, which is absent in the original project).
- `api/index.py` imports the FastAPI app from the project root and configures Vercel as web-only by default.
- `config/config.py` keeps MongoDB URI, database name, and base URL configuration together. Credentials are intentionally not hardcoded in source.

## Required Vercel settings
In Vercel → Project → Settings → Environment Variables, set:
- `MONGO_URI`: your MongoDB connection string (keep it private)
- `DB_NAME`: `anizoneflix` (or your actual database name)
- `BASE_URL`: `https://anizoneflix-vercel.vercel.app`
- `SECRET_KEY`: a long random secret
- `WEB_ONLY`: `true`

For MongoDB Atlas, add Vercel's outbound access as appropriate for your deployment setup (Atlas IP allowlisting can block serverless connections if restricted). Never commit your real MongoDB URI to GitHub.

## Deploy
1. Extract this ZIP and push the contents of `ANIZONEFLIX-main` to the GitHub repository connected to Vercel. Ensure `vercel.json`, `api/index.py`, `app.py`, `config/`, `database/`, `templates/`, and `static/` are at the repository root (not nested inside another `ANIZONEFLIX-main` directory).
2. Redeploy in Vercel with **Clear build cache** if the old deployment keeps appearing.
3. Test `/ping`; it should return JSON. `db:false` means the app is deployed but MongoDB credentials/network/database still need attention.
